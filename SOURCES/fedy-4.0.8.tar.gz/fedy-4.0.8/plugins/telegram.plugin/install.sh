#!/bin/bash

dnf copr -y enable rommon/telegram

dnf -y install telegram-desktop
