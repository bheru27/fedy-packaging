#!/bin/bash

dnf copr -y enable mosquito/atom
dnf -y install atom
