#!/bin/bash

dnf copr -y enable mosquito/vscode 
dnf -y install vscode
