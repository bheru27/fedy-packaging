#!/bin/bash

rm /etc/X11/xorg.conf.d/50-mouse-acceleration.conf
