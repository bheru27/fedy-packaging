#!/bin/bash

dnf copr -y enable phnxrbrn/evopop
dnf -y install evopop-icon-theme evopop-gtk-theme
