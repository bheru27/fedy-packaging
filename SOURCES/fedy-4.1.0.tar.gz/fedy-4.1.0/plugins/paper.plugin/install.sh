#!/bin/bash

dnf copr -y enable user501254/Paper
dnf -y install paper-gtk-theme paper-icon-theme
