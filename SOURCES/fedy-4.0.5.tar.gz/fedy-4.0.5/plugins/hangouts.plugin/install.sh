#!/bin/bash

dnf -y install https://dl.google.com/linux/direct/google-talkplugin_current_$(uname -i).rpm
