#!/bin/bash

pkill btsync

rm -fr "/opt/btsync"
