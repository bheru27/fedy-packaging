#!/bin/bash

dnf copr -y enable numix/numix
dnf -y install numix-icon-theme numix-icon-theme-circle numix-gtk-theme
