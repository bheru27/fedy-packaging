#!/bin/bash

dnf copr -y enable jgillich/brackets

dnf -y install brackets
