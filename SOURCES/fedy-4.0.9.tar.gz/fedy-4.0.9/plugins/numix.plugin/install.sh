#!/bin/bash

dnf copr -y enable satya164/numix
dnf -y install numix-icon-theme numix-icon-theme-circle numix-gtk-theme
