#!/bin/bash

dnf copr -y enable helber/atom
dnf -y install atom
